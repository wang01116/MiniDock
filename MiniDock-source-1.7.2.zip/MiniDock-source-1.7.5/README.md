# MiniDock 1.7.5 — source package

Native Win32 / GDI+ C project for 64-bit Windows. This package contains the complete source tree and MinGW-w64 build script. No prebuilt EXE is included.

## Build

1. Install a 64-bit MinGW-w64 toolchain that provides `gcc` and `windres` on `PATH`.
2. Run `build.bat` from this directory in `cmd.exe`.
3. A successful build creates `MiniDock.exe` in this directory.

## Changes in 1.7.5

- Replaced the thumbnail-overlay transition with direct movement/resizing of the real application HWND during minimize and restore; preserves the pre-animation restore placement.
- Reworked taskbar state application to call ABM_SETSTATE once for the primary taskbar, preserve a valid zero-valued original state, and apply hide/show to primary and secondary taskbars.
- On left/right docks, condenses enabled widgets into one 1×1 launcher with a menu listing every enabled widget.
- Added per-widget top status-bar context actions, an IME settings shortcut, and a separately persisted battery-widget toggle.
- Tightened the oversized explanatory panels in settings.
- See `更新说明-1.7.5.md` for details and test priorities.

## Diagnostic logging

Open **Settings → About → Problem diagnosis and logs** and enable **Collect logs**. Reproduce the problem, then export the diagnostic log. Logging is opt-in and disabled by default. It records lifecycle events and numeric status only; it does not record window captions, document names, full file paths, typed text, clipboard contents, or screenshots. The log is capped at about 2 MiB. Review it before sharing.

## Validation status

Static source checks and ZIP integrity checks were performed. This environment has no Windows MinGW-w64 compiler or `windres`; this source has not been compiled or tested on Windows. Direct HWND resizing during animation, maximized-window placement preservation, Explorer taskbar state changes, and side-dock widget launcher behaviour must be verified on a real Windows 10/11 machine before replacing an existing installation.
