# MiniDock 1.7.6 源码

这是 MiniDock 的 Windows 64 位原生 Win32 / GDI+ 源码包。

## 编译

安装 64 位 MinGW-w64（包含 `gcc` 与 `windres`），将其加入 PATH，在本目录运行 `build.bat`。

## 说明

- 配置文件与数据默认保存在 `%APPDATA%\MiniDock`，可通过设置更改数据目录。
- 诊断日志为用户主动开启的可选功能。
- 资源监视器温度与电池健康传感器指标尚未接入，详见 `更新说明-1.7.6.md`。
- 本包为源码包，不包含本次编译的 EXE；当前构建环境未提供 Windows MinGW-w64 工具链。
