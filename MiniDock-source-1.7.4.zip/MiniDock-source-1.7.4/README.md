# MiniDock 1.7.4 源码

这是 MiniDock 的 Windows 64 位源码包。配置和数据默认保存在 `%APPDATA%\MiniDock`。

使用包含 `gcc`、`g++`、`windres` 和 Windows SDK 导入库的 64 位 MinGW-w64 工具链，在本目录运行 `build.bat`。编译会链接 WinRT、Direct3D 11、DXGI 和 DirectComposition，用于 HDR 恢复快照。

随附的上游更新说明供历史查阅。仓库中的 `tests/` 提供回归脚本。本包包含构建源码及资源。
